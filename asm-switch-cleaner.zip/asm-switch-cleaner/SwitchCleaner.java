import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

/** Conservative edge specialization for constant-store / switch dispatchers.
 * Never executes input classes. Keeps state stores and original stack-map frames.
 */
public final class SwitchCleaner implements Opcodes {
    static AbstractInsnNode next(AbstractInsnNode n) {
        while (n != null && n.getOpcode() < 0) n = n.getNext();
        return n;
    }
    // Do not infer a constant across labels: another predecessor may enter there.
    static AbstractInsnNode prev(AbstractInsnNode n) {
        n = n.getPrevious();
        while (n instanceof FrameNode || n instanceof LineNumberNode) n = n.getPrevious();
        return n;
    }
    static Integer constant(AbstractInsnNode n) {
        if (n == null) return null;
        int op = n.getOpcode();
        if (op >= ICONST_M1 && op <= ICONST_5) return op - ICONST_0;
        if (op == BIPUSH || op == SIPUSH) return ((IntInsnNode)n).operand;
        if (n instanceof LdcInsnNode && ((LdcInsnNode)n).cst instanceof Integer)
            return (Integer)((LdcInsnNode)n).cst;
        return null;
    }
    static LabelNode destination(AbstractInsnNode sw, int value) {
        if (sw instanceof TableSwitchInsnNode) {
            TableSwitchInsnNode t = (TableSwitchInsnNode)sw;
            long ix = (long)value - t.min;
            return ix >= 0 && ix < t.labels.size() ? t.labels.get((int)ix) : t.dflt;
        }
        LookupSwitchInsnNode l = (LookupSwitchInsnNode)sw;
        int ix = Collections.binarySearch(l.keys, value);
        return ix >= 0 ? l.labels.get(ix) : l.dflt;
    }
    static final class Resolution {
        final LabelNode target;
        final int switches;
        Resolution(LabelNode t, int s) { target = t; switches = s; }
    }
    static Resolution resolve(LabelNode entry, int slot, int value) {
        Set<LabelNode> seen = Collections.newSetFromMap(new IdentityHashMap<>());
        LabelNode current = entry;
        int switches = 0;
        boolean bypassedDummy = false;
        for (int steps = 0; steps < 256; steps++) {
            if (!seen.add(current)) return null; // Preserve possible infinite loops.
            AbstractInsnNode a = next(current);
            if (a instanceof JumpInsnNode && a.getOpcode() == GOTO) {
                current = ((JumpInsnNode)a).label;
                continue;
            }
            if (a instanceof VarInsnNode && a.getOpcode() == ILOAD
                    && ((VarInsnNode)a).var == slot) {
                AbstractInsnNode b = next(a.getNext());
                if (b instanceof TableSwitchInsnNode || b instanceof LookupSwitchInsnNode) {
                    current = destination(b, value);
                    switches++;
                    continue;
                }
                // Some return-value trampolines do ILOAD state; POP; GOTO return.
                if (b != null && b.getOpcode() == POP) {
                    AbstractInsnNode c = next(b.getNext());
                    if (c instanceof JumpInsnNode && c.getOpcode() == GOTO) {
                        current = ((JumpInsnNode)c).label;
                        bypassedDummy = true;
                        continue;
                    }
                }
            }
            // Everything skipped above has zero net stack effect, no local writes,
            // and no calls/field accesses. Stop before the real case body.
            return (switches > 0 || bypassedDummy)
                ? new Resolution(current, switches) : null;
        }
        return null;
    }
    static int switches(MethodNode m) {
        int n = 0;
        for (AbstractInsnNode a : m.instructions)
            if (a instanceof TableSwitchInsnNode || a instanceof LookupSwitchInsnNode) n++;
        return n;
    }
    static int thread(MethodNode m) {
        int changed = 0;
        for (AbstractInsnNode a : m.instructions.toArray()) {
            if (!(a instanceof JumpInsnNode) || a.getOpcode() != GOTO) continue;
            AbstractInsnNode store = prev(a);
            if (!(store instanceof VarInsnNode) || store.getOpcode() != ISTORE) continue;
            Integer value = constant(prev(store));
            if (value == null) continue;
            JumpInsnNode jump = (JumpInsnNode)a;
            Resolution r = resolve(jump.label, ((VarInsnNode)store).var, value);
            if (r != null && r.target != jump.label) {
                jump.label = r.target;
                changed++;
            }
        }
        return changed;
    }
    static boolean hasCode(LabelNode start, LabelNode end) {
        for (AbstractInsnNode a = start; a != null && a != end; a = a.getNext())
            if (a.getOpcode() >= 0) return true;
        return false;
    }
    static int prune(String owner, MethodNode m) throws AnalyzerException {
        Frame<BasicValue>[] f = new Analyzer<BasicValue>(new BasicInterpreter()).analyze(owner, m);
        AbstractInsnNode[] nodes = m.instructions.toArray();
        int removed = 0;
        for (int i = 0; i < nodes.length; i++) {
            // Keep labels for debug tables / try boundaries. Remove dead frames too.
            if (f[i] == null && !(nodes[i] instanceof LabelNode)) {
                if (nodes[i].getOpcode() >= 0) removed++;
                m.instructions.remove(nodes[i]);
            }
        }
        m.tryCatchBlocks.removeIf(t -> !hasCode(t.start, t.end));
        if (m.localVariables != null) m.localVariables.removeIf(v -> !hasCode(v.start, v.end));
        // Dead ranges of local-variable type annotations can become invalid.
        // Debug-only annotations are dropped on changed methods; code annotations stay.
        m.visibleLocalVariableAnnotations = null;
        m.invisibleLocalVariableAnnotations = null;
        return removed;
    }
    static void verify(String owner, MethodNode m) throws AnalyzerException {
        if (m.instructions.size() != 0)
            new Analyzer<BasicValue>(new BasicVerifier()).analyze(owner, m);
    }
    static MethodNode copy(MethodNode m) {
        MethodNode c = new MethodNode(ASM9, m.access, m.name, m.desc, m.signature,
            m.exceptions == null ? null : m.exceptions.toArray(new String[0]));
        m.accept(c);
        return c;
    }
    static final class Counts {
        int classes, changedClasses, methods, edges, removed, before, after, skipped;
    }
    static byte[] clean(byte[] input, Counts stats, PrintWriter log) {
        ClassNode c = new ClassNode();
        new ClassReader(input).accept(c, ClassReader.EXPAND_FRAMES);
        boolean changed = false;
        Set<Integer> changedMethods = new HashSet<>();
        for (int mi = 0; mi < c.methods.size(); mi++) {
            MethodNode original = c.methods.get(mi);
            int before = switches(original);
            stats.before += before;
            if (before == 0) continue;
            MethodNode m = copy(original);
            try {
                int edges = thread(m);
                if (edges == 0) {
                    stats.after += before;
                    log.printf("KEEP\t%s\t%s%s\tswitches=%d\tno_matching_constant_edge%n",
                        c.name, m.name, m.desc, before);
                    continue;
                }
                int removed = prune(c.name, m);
                verify(c.name, m);
                c.methods.set(mi, m);
                changedMethods.add(mi);
                int after = switches(m);
                stats.after += after;
                stats.methods++; stats.edges += edges; stats.removed += removed;
                changed = true;
                log.printf("OK\t%s\t%s%s\tedges=%d\tswitches=%d->%d\tdead_insns=%d%n",
                    c.name, m.name, m.desc, edges, before, after, removed);
            } catch (Exception e) {
                stats.after += before; stats.skipped++;
                log.printf("SKIP\t%s\t%s%s\t%s%n", c.name, original.name, original.desc,
                    e.toString().replace('\n', ' '));
            }
        }
        if (!changed) return input;
        // Preserve existing full frames; state stores remain, so dispatcher removal
        // changes neither locals nor operand stack at case entry. No class loading.
        ClassWriter writer = new ClassWriter(0);
        c.accept(writer);
        byte[] output = writer.toByteArray();
        // Verify serialized output too (not a full JVM verification / runtime test).
        ClassNode check = new ClassNode();
        new ClassReader(output).accept(check, ClassReader.EXPAND_FRAMES);
        for (int ix : changedMethods) {
                try { verify(check.name, check.methods.get(ix)); }
                catch (AnalyzerException e) { throw new IllegalStateException(e); }
        }
        stats.changedClasses++;
        return output;
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 3) {
            System.err.println("Usage: java -cp 'classes:deps/*' SwitchCleaner input.jar output.jar report.txt");
            System.exit(2);
        }
        Path in = Path.of(args[0]).toAbsolutePath().normalize();
        Path out = Path.of(args[1]).toAbsolutePath().normalize();
        Path report = Path.of(args[2]).toAbsolutePath().normalize();
        if (in.equals(out) || in.equals(report) || out.equals(report))
            throw new IllegalArgumentException("Input, output and report must differ");
        Files.createDirectories(out.getParent());
        Files.createDirectories(report.getParent());
        Counts stats = new Counts();
        try (JarFile jar = new JarFile(in.toFile(), false);
             JarOutputStream dst = new JarOutputStream(Files.newOutputStream(out));
             PrintWriter log = new PrintWriter(Files.newBufferedWriter(report))) {
            Enumeration<JarEntry> entries = jar.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String name = entry.getName();
                // Modifying class bytes invalidates JAR signing metadata.
                String upper = name.toUpperCase(Locale.ROOT);
                if (upper.startsWith("META-INF/") && (upper.endsWith(".SF")
                    || upper.endsWith(".RSA") || upper.endsWith(".DSA") || upper.endsWith(".EC"))) {
                    log.println("DROP_SIGNATURE\t" + name); continue;
                }
                byte[] bytes;
                try (InputStream src = jar.getInputStream(entry)) { bytes = src.readAllBytes(); }
                if (name.endsWith(".class")) {
                    stats.classes++;
                    try { bytes = clean(bytes, stats, log); }
                    catch (Exception e) {
                        log.println("CLASS_FALLBACK\t" + name + "\t" + e);
                        throw new IOException("Class output validation failed: " + name, e);
                    }
                }
                JarEntry target = new JarEntry(name);
                if (entry.getTime() != -1) target.setTime(entry.getTime());
                dst.putNextEntry(target); dst.write(bytes); dst.closeEntry();
            }
            String summary = String.format(Locale.ROOT,
                "classes=%d changed_classes=%d changed_methods=%d specialized_edges=%d switches=%d->%d dead_insns=%d skipped_methods=%d",
                stats.classes, stats.changedClasses, stats.methods, stats.edges,
                stats.before, stats.after, stats.removed, stats.skipped);
            log.println(summary); System.out.println(summary);
        }
    }
}
