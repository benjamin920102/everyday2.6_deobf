# ASM switch 批量化簡工具

已依附上的 EveryDay-v2_6-Windows-fixed-native.jar 實際處理。
工具使用 ASM 9.8；Java 17 以上可執行工具。原 mod 的 class version 65（Java 21）保持不變。

## 直接使用

解壓縮後，在工具資料夾開啟終端機。classes/ 內已有編譯好的工具，deps/ 已附執行所需 ASM JAR。

Windows（PowerShell / cmd）：

```powershell
java -Xmx2g -cp "classes;deps/*" SwitchCleaner "input.jar" "output.jar" "report.txt"
```

Linux / macOS：

```bash
java -Xmx2g -cp 'classes:deps/*' SwitchCleaner input.jar output.jar report.txt
```

請將 input.jar 換成原始 JAR 路徑；輸出路徑須與輸入不同。output.jar、report.txt 若已存在會覆寫。
已處理的檔案在 output/EveryDay-switch-cleaned.jar；完整方法報告在 output/report.txt。
examples/FireworkBoost.cleaned.cfr.java 是反編譯閱讀範例，保留原有非法 Java 名稱，不能直接拿來編譯。

## 實際解法

此 JAR 大量出現以下形狀：

```text
LDC -1921431709
ISTORE 1
GOTO dispatcher

dispatcher:
ILOAD 1
TABLESWITCH ... -1921431709: casePlayerPitch ...
```

工具在每個「入口邊」使用已知常數，將 GOTO dispatcher 改成 GOTO casePlayerPitch。
它也支援 LOOKUPSWITCH、default，以及 ILOAD state / POP / GOTO 型的無效返回跳板。
原本的 LDC / ISTORE 保留，因此 case 內如果讀取 state，其值不會改變。

只跳過無副作用、stack 淨變化為零的 dispatcher；遇到呼叫、欄位讀寫、真正條件判斷即停止。
不會執行輸入 JAR、載入其類別、解開 native 程式碼或修改巢狀 JAR。
工具不跨 Label 推測來源常數，也不處理任意算術表達式或動態狀態。

之後使用 Analyzer<BasicValue>(new BasicInterpreter()) 做可達性分析，刪除不可達指令與 frame。
再以 Analyzer<BasicValue>(new BasicVerifier()) 檢查變更方法，並對序列化輸出再檢查一次。
不能通過方法檢查時，保留該方法原樣，於報告記錄 SKIP。
報告中的 KEEP 表示該方法有 switch，但沒有匹配到工具支援的常數入口。

保留原有 stack-map frames，使用 ClassWriter(0)，不依賴完整 Minecraft classpath 重新計算類別繼承關係。
刪除變更方法的 local-variable type annotations（除錯中繼資料）；保留其餘程式碼註記。
JAR 的舊簽章檔（.SF/.RSA/.DSA/.EC）會移除，因修改後舊簽章不再有效。

## 本次結果

| 項目 | 數量 |
| --- | ---: |
| 頂層 class | 1,007 |
| 修改 class | 253 |
| 修改方法 | 1,689 |
| 改接跳轉 | 25,926 |
| switch | 3,532 → 65 |
| 移除不可達指令 | 26,924 |
| 因方法檢查失敗而跳過 | 0 |

剩下的 65 個 switch 可能是真正的資料分支或不符合此規則的模式，工具保留它們。
FireworkBoost（obf/oo0oOO）內的 switch 已全部移除；未進行類別／方法重命名或 Minecraft mappings 還原。

## 驗證與限制

- 每個變更方法均通過 ASM BasicVerifier，序列化輸出後再次檢查。
- CleanerTests 使用自建 bytecode fixture，以 JVM -Xverify:all 執行 31 組前後行為比較。
- fixture 涵蓋負數常數、default、TABLESWITCH、LOOKUPSWITCH、stack 既有 float/long、真正動態 switch、迴圈、case 呼叫及例外 handler。
- 自建測試與本次 JAR 的第二次處理均無新增修改。
- 未執行輸入 JAR，未在 Minecraft / Fabric / Windows native 環境測試。ASM BasicVerifier 不等同完整 JVM 型別驗證或遊戲相容性驗證。
- 此工具針對本次 JAR 的明確模式，並非通用 deobfuscator。名稱混淆與其他混淆仍會存在。

## 修改並重新編譯

需要 JDK 17 以上的 javac。在本資料夾執行：

Windows：

```powershell
javac -encoding UTF-8 -cp "deps/*" -d classes SwitchCleaner.java CleanerTests.java
java -Xverify:all -cp "classes;deps/*" CleanerTests
```

Linux / macOS：

```bash
javac -encoding UTF-8 -cp 'deps/*' -d classes SwitchCleaner.java CleanerTests.java
java -Xverify:all -cp 'classes:deps/*' CleanerTests
```

工具原始碼核心入口：thread() 辨識常數入口，resolve() 決定 case 目標，prune() 清除不可達程式碼。
ASM 依賴使用 BSD 3-Clause license，完整授權見 ASM-LICENSE.txt。

官方參考：

- https://asm.ow2.io/
- https://asm.ow2.io/javadoc/org/objectweb/asm/tree/analysis/Analyzer.html
- https://asm.ow2.io/javadoc/org/objectweb/asm/tree/analysis/BasicVerifier.html
