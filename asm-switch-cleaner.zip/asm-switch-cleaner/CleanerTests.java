import java.io.*;
import java.util.*;
import org.objectweb.asm.*;

/** Only loads locally generated fixtures, never classes from the uploaded JAR. */
public final class CleanerTests implements Opcodes {
    static class Loader extends ClassLoader {
        Class<?> define(byte[] b) { return defineClass(null, b, 0, b.length); }
    }
    static MethodVisitor method(ClassWriter w, String name, String desc) {
        MethodVisitor v = w.visitMethod(ACC_PUBLIC | ACC_STATIC, name, desc, null, null);
        v.visitCode(); return v;
    }
    static void end(MethodVisitor v) { v.visitMaxs(0, 0); v.visitEnd(); }
    static void state(MethodVisitor v, int value, Label dispatcher) {
        v.visitLdcInsn(value); v.visitVarInsn(ISTORE, 1); v.visitJumpInsn(GOTO, dispatcher);
    }
    static byte[] fixture() {
        ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS);
        w.visit(V17, ACC_PUBLIC, "CleanerFixture", null, "java/lang/Object", null);
        MethodVisitor v = method(w, "branch", "(I)I");
        Label d = new Label(), a = new Label(), b = new Label(), choose = new Label();
        v.visitVarInsn(ILOAD, 0); v.visitJumpInsn(IFEQ, choose);
        state(v, -1711712220, d);
        v.visitLabel(choose); state(v, 999, d);
        v.visitLabel(d); v.visitVarInsn(ILOAD, 1);
        v.visitLookupSwitchInsn(b, new int[]{-1711712220}, new Label[]{a});
        v.visitLabel(a); v.visitVarInsn(ILOAD, 1); v.visitInsn(IRETURN);
        v.visitLabel(b); v.visitIntInsn(BIPUSH, 42); v.visitInsn(IRETURN); end(v);

        v = method(w, "stackFloat", "()F");
        d = new Label(); a = new Label(); b = new Label();
        v.visitLdcInsn(3.25f); state(v, 7, d);
        v.visitLabel(d); v.visitVarInsn(ILOAD, 1); v.visitTableSwitchInsn(7, 7, b, a);
        v.visitLabel(a); v.visitInsn(FRETURN);
        v.visitLabel(b); v.visitInsn(POP); v.visitLdcInsn(-1f); v.visitInsn(FRETURN); end(v);

        v = method(w, "dummyReturn", "()J");
        d = new Label(); a = new Label(); b = new Label();
        v.visitLdcInsn(1234567890123L); state(v, 4, d);
        v.visitLabel(d); v.visitVarInsn(ILOAD, 1); v.visitTableSwitchInsn(4, 4, b, a);
        v.visitLabel(a); v.visitVarInsn(ILOAD, 1); v.visitInsn(POP);
        v.visitJumpInsn(GOTO, b); v.visitLabel(b); v.visitInsn(LRETURN); end(v);

        // Real switch depends on a caller argument: it must remain.
        v = method(w, "realSwitch", "(I)I");
        d = new Label(); a = new Label(); b = new Label();
        v.visitVarInsn(ILOAD, 0); v.visitVarInsn(ISTORE, 1); v.visitJumpInsn(GOTO, d);
        v.visitLabel(d); v.visitVarInsn(ILOAD, 1); v.visitTableSwitchInsn(1, 1, b, a);
        v.visitLabel(a); v.visitInsn(ICONST_3); v.visitInsn(IRETURN);
        v.visitLabel(b); v.visitInsn(ICONST_5); v.visitInsn(IRETURN); end(v);

        v = method(w, "loop", "(I)I");
        d = new Label(); a = new Label(); b = new Label(); Label done = new Label();
        state(v, 10, d);
        v.visitLabel(d); v.visitVarInsn(ILOAD, 1); v.visitTableSwitchInsn(10, 11, done, a, b);
        v.visitLabel(a); v.visitVarInsn(ILOAD, 0); v.visitJumpInsn(IFLE, done);
        v.visitIincInsn(0, -1); state(v, 11, d);
        v.visitLabel(b); state(v, 10, d);
        v.visitLabel(done); v.visitVarInsn(ILOAD, 0); v.visitInsn(IRETURN); end(v);

        // Keep side effects at a case entry, even when it starts with ILOAD state.
        v = method(w, "sideEffect", "()I");
        d = new Label(); a = new Label(); b = new Label();
        state(v, 2, d);
        v.visitLabel(d); v.visitVarInsn(ILOAD, 1); v.visitTableSwitchInsn(2, 2, b, a);
        v.visitLabel(a); v.visitVarInsn(ILOAD, 1);
        v.visitMethodInsn(INVOKESTATIC, "java/lang/Math", "negateExact", "(I)I", false);
        v.visitInsn(IRETURN);
        v.visitLabel(b); v.visitInsn(ICONST_0); v.visitInsn(IRETURN); end(v);

        // Exception edges must keep a live handler and its stack map.
        v = method(w, "handler", "(I)I");
        d = new Label(); a = new Label(); b = new Label();
        Label start = new Label(), stop = new Label(), handler = new Label();
        v.visitTryCatchBlock(start, stop, handler, "java/lang/ArithmeticException");
        state(v, 8, d);
        v.visitLabel(d); v.visitVarInsn(ILOAD, 1); v.visitTableSwitchInsn(8, 8, b, a);
        v.visitLabel(a); v.visitLabel(start); v.visitIntInsn(BIPUSH, 12);
        v.visitVarInsn(ILOAD, 0); v.visitInsn(IDIV); v.visitLabel(stop); v.visitInsn(IRETURN);
        v.visitLabel(handler); v.visitInsn(POP); v.visitInsn(ICONST_M1); v.visitInsn(IRETURN);
        v.visitLabel(b); v.visitInsn(ICONST_0); v.visitInsn(IRETURN); end(v);
        w.visitEnd(); return w.toByteArray();
    }
    static void compare(Class<?> a, Class<?> b, String name, Class<?>[] types, Object... args)
            throws Exception {
        Object x = a.getMethod(name, types).invoke(null, args);
        Object y = b.getMethod(name, types).invoke(null, args);
        if (!Objects.equals(x, y)) throw new AssertionError(name + ": " + x + " != " + y);
    }
    public static void main(String[] args) throws Exception {
        byte[] original = fixture();
        SwitchCleaner.Counts counts = new SwitchCleaner.Counts();
        StringWriter report = new StringWriter();
        byte[] cleaned = SwitchCleaner.clean(original, counts, new PrintWriter(report));
        Class<?> before = new Loader().define(original), after = new Loader().define(cleaned);
        Class<?>[] oneInt = {int.class}, none = {};
        int comparisons = 0;
        for (int i : new int[]{-100, -1, 0, 1, 2, 20, 100}) {
            for (String name : new String[]{"branch", "realSwitch", "loop", "handler"}) {
                compare(before, after, name, oneInt, i); comparisons++;
            }
        }
        for (String name : new String[]{"stackFloat", "dummyReturn", "sideEffect"}) {
            compare(before, after, name, none); comparisons++;
        }
        if (counts.before != 7 || counts.after != 1 || counts.methods != 6)
            throw new AssertionError("Unexpected counts: " + report);
        SwitchCleaner.Counts twice = new SwitchCleaner.Counts();
        byte[] second = SwitchCleaner.clean(cleaned, twice, new PrintWriter(new StringWriter()));
        if (!Arrays.equals(cleaned, second) || twice.methods != 0)
            throw new AssertionError("Not idempotent");
        System.out.println("PASS: " + comparisons + " behavioral comparisons; real switch retained; "
            + "JVM verification; exception handler; stack values; idempotence.");
    }
}
