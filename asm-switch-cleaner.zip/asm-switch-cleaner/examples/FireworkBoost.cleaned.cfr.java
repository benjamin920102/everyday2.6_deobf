/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1671
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2708
 *  net.minecraft.class_2743
 *  net.minecraft.class_2828
 *  net.minecraft.class_746
 *  obf.00o
 *  obf.0O
 *  obf.0oO0O
 *  obf.O00oOO
 *  obf.O0o0
 *  obf.OOOOO
 *  obf.OOo000
 *  obf.OoO0o0
 *  obf.mixins.o0
 *  obf.o0OOOO
 *  obf.oOo000
 *  obf.oo0o0o
 */
package obf;

import java.util.Iterator;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1671;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2828;
import net.minecraft.class_746;
import obf.00o;
import obf.0O;
import obf.0oO0O;
import obf.O00oOO;
import obf.O0o0;
import obf.OOOOO;
import obf.OOo000;
import obf.OoO0o0;
import obf.mixins.o0;
import obf.o0OOOO;
import obf.oOo000;
import obf.oo0o0o;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Duplicate member names - consider using --renamedupmembers true
 */
public class oo0oOO
extends O00oOO {
    public static oo0oOO INSTANCE;
    public final oOo000 boost;
    public final 00o baseVelocity;
    public final 00o velocity;
    public final 00o yClimbCap;
    public final 00o safetyMargin;
    public final 00o baseY;
    public final oOo000 noInYBoost;
    public final oOo000 yBoost;
    public final 00o basePitch;
    public final 00o minPitch;
    public final 00o maxPitch;
    public final 00o modulePause;
    private final oOo000 lagPause;
    public final 00o pauseTicks;
    private final oOo000 yawJitter;
    public final 00o jitter;
    public final 00o waitFireworkTick;
    public class_243 sentVelocity;
    class_243 lastSentPos;
    public class_243 nextRequestVelocity;
    float thisPitch;
    public int pauseTick;
    int waitTicks;

    public oo0oOO() {
        super("FireworkBoost", "Boost your firework", OOOOO.Movement);
        oo0oOO oo0oOO2;
        oo0oOO2.boost = oo0oOO2.O(new oOo000("Boost", true));
        oo0oOO2.baseVelocity = oo0oOO2.O(new 00o("BaseVelocity", 1.7, 0.1, 2.0, 0.1));
        oo0oOO2.velocity = oo0oOO2.O(new 00o("Velocity", 1.65, 0.1, 10.0, 0.1));
        oo0oOO2.yClimbCap = oo0oOO2.O(new 00o("YClimbCap", 0.0, 0.0, 10.0, 0.1));
        oo0oOO2.safetyMargin = oo0oOO2.O(new 00o("SafetyMargin", 0.0, 0.0, 1.0, 0.01));
        oo0oOO2.baseY = oo0oOO2.O(new 00o("BaseY", 0.02, 0.0, 1.0, 0.01));
        oo0oOO2.noInYBoost = oo0oOO2.O(new oOo000("NoInYBoost", true));
        oo0oOO2.yBoost = oo0oOO2.O(new oOo000("YBoost", false));
        oo0oOO2.basePitch = oo0oOO2.O(new 00o("BasePitch", 10.0, 0.0, 60.0, 1.0));
        oo0oOO2.minPitch = oo0oOO2.O(new 00o("MinPitch", 45.0, 0.0, 60.0, 1.0));
        oo0oOO2.maxPitch = oo0oOO2.O(new 00o("MaxPitch", 60.0, 60.0, 90.0, 1.0));
        oo0oOO2.modulePause = oo0oOO2.O(new 00o("ModulePause", 10.0, 0.0, 40.0, 1.0));
        oo0oOO2.lagPause = oo0oOO2.O(new oOo000("LagPause", true));
        oo0oOO2.pauseTicks = oo0oOO2.O(new 00o("PauseTicks", 10.0, 0.0, 40.0, 1.0));
        oo0oOO2.yawJitter = oo0oOO2.O(new oOo000("YawJitter", true));
        oo0oOO2.jitter = oo0oOO2.O(new 00o("Jitter", 0.01, 0.01, 0.1, 0.01));
        oo0oOO2.waitFireworkTick = oo0oOO2.O(new 00o("WaitFireworkTick", 1.0, 0.0, 5.0, 1.0));
        oo0oOO2.sentVelocity = null;
        oo0oOO2.lastSentPos = null;
        oo0oOO2.nextRequestVelocity = null;
        oo0oOO2.thisPitch = 0.0f;
        oo0oOO2.pauseTick = 0;
        oo0oOO2.waitTicks = 0;
        INSTANCE = oo0oOO2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean O0() {
        int n = -1711712220;
        if (!this.0()) return 0 != 0;
        n = -1711712223;
        if (oo0oOO.Oo()) return 0 != 0;
        n = -1711712222;
        if (!oo0oOO.mc.field_1724.method_6128()) return 0 != 0;
        return 1 != 0;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private float O() {
        int n = -1921431711;
        if (!this.O0()) return 0oO0O.ROTATION.rotationPitch;
        return oo0oOO.mc.field_1724.method_36455();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private float o() {
        int n = -79520982;
        if (!this.O0()) return 0oO0O.ROTATION.rotationYaw;
        return oo0oOO.mc.field_1724.method_36454();
    }

    /*
     * Enabled aggressive block sorting
     */
    public float 0() {
        float f;
        int n = 989372958;
        if (!this.0()) return 0.0f;
        n = 989372956;
        if (!this.yawJitter.o()) return 0.0f;
        n = 989372962;
        if (oo0oOO.Oo()) {
            return 0.0f;
        }
        n = 989372965;
        if (!oo0oOO.mc.field_1724.method_6128()) {
            return 0.0f;
        }
        n = 989372957;
        if (oo0oOO.mc.field_1724.field_6012 % 2 == 0) {
            n = 989372964;
            f = this.jitter.O();
            return f;
        }
        n = 989372963;
        f = -this.jitter.O();
        return f;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean oO() {
        int n = -1650062338;
        oo0oOO oo0oOO2 = INSTANCE;
        if (oo0oOO2 == null) return false;
        n = 1167021025;
        if (!oo0oOO2.O0()) return false;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean oo() {
        int n = 1318540750;
        Iterator iterator = oo0oOO.mc.field_1687.method_18112().iterator();
        n = 735365667;
        while (true) {
            block5: {
                block4: {
                    block3: {
                        block2: {
                            if (!iterator.hasNext()) break block2;
                            n = 735365666;
                            class_1297 class_12972 = (class_1297)iterator.next();
                            if (!(class_12972 instanceof class_1671)) break block3;
                            n = -218935099;
                            class_1671 class_16712 = (class_1671)class_12972;
                            if (((o0)class_16712).getShooter() == oo0oOO.mc.field_1724) {
                                n = -1105914510;
                                this.waitTicks = 0;
                                return true;
                            }
                            break block4;
                        }
                        n = 735365669;
                        if (this.waitTicks > this.waitFireworkTick.O()) return false;
                        return true;
                    }
                    n = -218935098;
                    break block5;
                }
                n = -218935098;
            }
            n = 735365667;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @OoO0o0
    public void O(O0o0 o0o0) {
        boolean bl;
        class_746 class_7462;
        class_243 class_2432;
        class_243 class_2433;
        block9: {
            int n;
            block7: {
                block8: {
                    block6: {
                        float f;
                        float f2;
                        int n2;
                        block3: {
                            block5: {
                                block4: {
                                    block2: {
                                        n = -1779170828;
                                        if (oo0oOO.Oo()) return;
                                        n = -1779170829;
                                        if (!o0o0.0()) {
                                            return;
                                        }
                                        n = -1779170822;
                                        ++this.waitTicks;
                                        if (this.pauseTick > 0) {
                                            n = -1779170825;
                                            --this.pauseTick;
                                            this.nextRequestVelocity = null;
                                            return;
                                        }
                                        n = -1779170826;
                                        this.nextRequestVelocity = null;
                                        if (!oo0oOO.mc.field_1724.method_6128()) return;
                                        n = -1779170830;
                                        if (!this.oo()) return;
                                        n = -1779170821;
                                        n2 = 0;
                                        f2 = this.O();
                                        f = this.o();
                                        this.thisPitch = f2;
                                        if (this.yBoost.o()) break block2;
                                        n = -164772365;
                                        break block3;
                                    }
                                    n = -164772363;
                                    if (!((double)f2 > this.minPitch.o())) break block4;
                                    n = -164772364;
                                    if (!(this.maxPitch.o() > (double)f2)) break block5;
                                    n = -164772366;
                                    this.thisPitch = this.basePitch.O();
                                    n2 = 1;
                                    n = -164772365;
                                    break block3;
                                }
                                n = -164772365;
                                break block3;
                            }
                            n = -164772365;
                        }
                        class_243 class_2434 = 0O.O((float)f2, (float)f);
                        class_243 class_2435 = 0O.O((float)this.thisPitch, (float)f);
                        class_2433 = new class_243(class_2435.field_1352, class_2434.field_1351, class_2435.field_1350);
                        class_2432 = class_2433.method_18805(this.baseVelocity.o(), this.baseVelocity.o(), this.baseVelocity.o());
                        class_7462 = oo0oOO.mc.field_1724;
                        if (n2 == 0) break block6;
                        n = -1272402950;
                        if (this.noInYBoost.o()) break block7;
                        n = -1272402949;
                        break block8;
                    }
                    n = -1272402949;
                }
                bl = true;
                n = 2124531321;
                break block9;
            }
            n = -1272402948;
            bl = false;
            n = 2124531321;
        }
        class_7462.method_18799(this.O(class_2432, class_2433, bl));
    }

    /*
     * Enabled aggressive block sorting
     */
    @OoO0o0
    public void O(oo0o0o oo0o0o2) {
        int n = -423342167;
        if (oo0oOO.Oo()) {
            return;
        }
        n = -423342164;
        class_2596 class_25962 = oo0o0o2.O();
        if (!(class_25962 instanceof class_2828)) return;
        n = -654399057;
        class_2828 class_28282 = (class_2828)class_25962;
        if (!class_28282.method_36171()) {
            return;
        }
        n = 1666710827;
        class_25962 = new class_243(class_28282.method_12269(0.0), class_28282.method_12268(0.0), class_28282.method_12274(0.0));
        if (this.lastSentPos == null) {
            n = 734164706;
        } else {
            n = 734164707;
            this.sentVelocity = class_25962.method_1020(this.lastSentPos);
            n = 734164706;
        }
        this.lastSentPos = class_25962;
    }

    /*
     * Enabled aggressive block sorting
     */
    public class_243 O(class_243 class_2432, class_243 class_2433, boolean bl) {
        int n = 2004964458;
        if (!this.boost.o()) return class_2432;
        n = 2004964456;
        if (bl) return o0OOOO.O((class_243)class_2432, (class_243)class_2433);
        return class_2432;
    }

    /*
     * Enabled aggressive block sorting
     */
    public class_243 O(class_243 class_2432, double d, double d2, double d3) {
        double d4;
        int n;
        block6: {
            block7: {
                block5: {
                    block4: {
                        n = -69798821;
                        double d5 = this.yClimbCap.o();
                        if (!(d5 > 0.0)) break block4;
                        n = 1578625031;
                        if (!Double.isFinite(d5)) break block5;
                        n = 1578625033;
                        d4 = d5;
                        n = 1232212195;
                        break block6;
                    }
                    n = 1578625034;
                    break block7;
                }
                n = 1578625034;
            }
            d4 = Double.MAX_VALUE;
            n = 1232212195;
        }
        double d6 = d4;
        double d7 = class_2432.field_1351;
        if (d > 0.0) {
            n = 258305203;
            d7 = Math.max(d7, Math.min(d3, d6));
            n = 258305202;
        } else {
            n = 258305201;
            if (!(d < 0.0)) {
                n = 258305202;
            } else {
                n = 258305205;
                d7 = Math.min(d7, Math.max(d2, -d6));
                n = 258305202;
            }
        }
        d7 = Math.clamp((double)d7, (double)d2, (double)d3);
        return new class_243(class_2432.field_1352, d7, class_2432.field_1350);
    }

    /*
     * Enabled aggressive block sorting
     */
    public class_243 O() {
        int n = 1131508072;
        if (this.nextRequestVelocity == null) return null;
        n = 1131508073;
        class_243 class_2432 = this.nextRequestVelocity;
        this.nextRequestVelocity = null;
        return class_2432;
    }

    /*
     * Enabled aggressive block sorting
     */
    public class_243 O(class_1309 class_13092, class_243 class_2432, class_243 class_2433, boolean bl) {
        double d;
        class_243 class_2434;
        double d2;
        double d3;
        class_243 class_2435;
        int n;
        block7: {
            block6: {
                block5: {
                    float f;
                    block4: {
                        block3: {
                            block2: {
                                double d4;
                                n = -820617702;
                                class_2435 = class_2433;
                                float f2 = oo0oOO.O(class_2433);
                                f = f2 * ((float)Math.PI / 180);
                                d3 = Math.sqrt(class_2435.field_1352 * class_2435.field_1352 + class_2435.field_1350 * class_2435.field_1350);
                                d2 = class_2432.method_37267();
                                if (bl) {
                                    n = -867381604;
                                    d4 = oo0oOO.O((class_1297)class_13092);
                                    n = 843341811;
                                } else {
                                    n = -867381605;
                                    d4 = 0.0;
                                    n = 843341811;
                                }
                                double d5 = d4;
                                double d6 = Math.cos(f) * Math.cos(f);
                                double d7 = class_2432.field_1351 + d5 * (d6 * 0.75 - 1.0);
                                class_2434 = new class_243(class_2432.field_1352, d7, class_2432.field_1350);
                                if (!(d7 < 0.0)) break block2;
                                n = 1683570391;
                                if (!(d3 > 0.0)) break block3;
                                n = 1683570390;
                                d = d7 * -0.1 * d6;
                                class_2434 = class_2434.method_1031(class_2435.field_1352 * d / d3, d, class_2435.field_1350 * d / d3);
                                n = 1683570394;
                                break block4;
                            }
                            n = 1683570394;
                            break block4;
                        }
                        n = 1683570394;
                    }
                    if (!(f < 0.0f)) break block5;
                    n = 1683570392;
                    if (!(d3 > 0.0)) break block6;
                    n = 1683570388;
                    d = d2 * -Math.sin(f) * 0.04;
                    class_2434 = class_2434.method_1031(-class_2435.field_1352 * d / d3, d * 3.2, -class_2435.field_1350 * d / d3);
                    n = 1683570386;
                    break block7;
                }
                n = 1683570386;
                break block7;
            }
            n = 1683570386;
        }
        if (!(d3 > 0.0)) return class_2434.method_18805((double)0.99f, (double)0.98f, (double)0.99f);
        n = 1683570389;
        d = d2 / d3;
        class_2434 = class_2434.method_1031((class_2435.field_1352 * d - class_2434.field_1352) * 0.1, 0.0, (class_2435.field_1350 * d - class_2434.field_1350) * 0.1);
        return class_2434.method_18805((double)0.99f, (double)0.98f, (double)0.99f);
    }

    public static float O(class_243 class_2432) {
        return (float)Math.toDegrees(Math.asin(-class_2432.field_1351));
    }

    public class_243 O(float f, float f2) {
        float f3 = f * ((float)Math.PI / 180);
        float f4 = -f2 * ((float)Math.PI / 180);
        float f5 = (float)Math.cos(f4);
        float f6 = (float)Math.sin(f4);
        float f7 = (float)Math.cos(f3);
        float f8 = (float)Math.sin(f3);
        return new class_243((double)(f6 * f7), (double)(-f8), (double)(f5 * f7));
    }

    /*
     * Enabled aggressive block sorting
     */
    public static double O(class_1297 class_12972) {
        boolean bl;
        int n = -215329453;
        if (class_12972.method_18798().field_1351 <= 0.0) {
            n = -215329454;
            bl = true;
            n = 1851699997;
        } else {
            n = -215329452;
            bl = false;
            n = 1851699997;
        }
        boolean bl2 = bl;
        return class_12972.method_7490();
    }

    /*
     * Enabled aggressive block sorting
     */
    @OoO0o0
    public void O(OOo000 oOo0002) {
        int n = -1741686940;
        if (oo0oOO.Oo()) {
            return;
        }
        n = -1741686941;
        if (oOo0002.O() instanceof class_2708) {
            n = -1741686939;
            this.sentVelocity = null;
            this.lastSentPos = null;
            if (!this.lagPause.o()) return;
            n = -1741686945;
            this.pauseTick = this.pauseTicks.O();
            return;
        }
        n = -1741686944;
        class_2596 class_25962 = oOo0002.O();
        if (!(class_25962 instanceof class_2743)) return;
        n = -1794531352;
        class_2743 class_27432 = (class_2743)class_25962;
        if (class_27432.method_11818() != oo0oOO.mc.field_1724.method_5628()) return;
        n = 100641614;
        class_25962 = new class_243(class_27432.method_11815(), class_27432.method_11816(), class_27432.method_11819());
        if (!(class_25962.method_1027() <= 100.0)) return;
        n = -1037537501;
        this.sentVelocity = class_25962;
    }
}
